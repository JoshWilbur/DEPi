export OMP_NUM_THREADS=$1 # Use argument to set threads
./gol_omp